import json
import os
import uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).parent
DATA_FILE = ROOT / "data.json"

DEFAULT_DATA = {
    "users": [
        {"id": "u-student", "name": "Aisha Bello", "matric": "MAU/CSC/21/047", "phone": "+234 803 441 2290", "hostel": "Female Hostel B", "room": "B-204", "role": "student", "email": "aisha.bello@mau.edu.ng", "password": "student123"},
        {"id": "u-admin", "name": "Campus Safety Desk", "matric": "", "phone": "+234 806 000 1122", "role": "admin", "email": "safety@mau.edu.ng", "password": "admin123"},
        {"id": "u-security", "name": "Security Office", "matric": "", "phone": "+234 806 000 1122", "role": "security", "email": "security@mau.edu.ng", "password": "security123"},
        {"id": "u-clinic", "name": "MAU Clinic", "matric": "", "phone": "+234 806 000 1133", "role": "clinic", "email": "clinic@mau.edu.ng", "password": "clinic123"},
        {"id": "u-fire", "name": "Fire Service", "matric": "", "phone": "+234 806 000 1144", "role": "fire", "email": "fire@mau.edu.ng", "password": "fire123"}
    ],
    "alerts": [
        {"id": "AL-2408", "type": "Medical", "student": "Ibrahim Musa", "matric": "MAU/ENG/22/118", "phone": "+234 809 111 0064", "location": "Lecture Theatre II", "lat": 10.2893, "lng": 9.8181, "status": "Responding", "time": "2026-08-21T09:42:00Z", "channel": "Push + SMS"},
        {"id": "AL-2407", "type": "Security threat", "student": "Chiamaka Okafor", "matric": "MAU/SCI/23/031", "phone": "+234 807 991 4421", "location": "Female Hostel B", "lat": 10.2911, "lng": 9.8217, "status": "Resolved", "time": "2026-08-21T08:18:00Z", "channel": "Push + SMS"},
        {"id": "AL-2406", "type": "Fire", "student": "Yusuf Abdullahi", "matric": "MAU/AGR/21/202", "phone": "+234 812 008 7344", "location": "Science Complex", "lat": 10.2876, "lng": 9.8159, "status": "Resolved", "time": "2026-08-20T16:27:00Z", "channel": "Push + SMS"}
    ],
    "contacts": [
        {"id": "c-1", "name": "Campus Security Desk", "detail": "+234 806 000 1122", "kind": "Security"},
        {"id": "c-2", "name": "MAU Clinic", "detail": "+234 806 000 1133", "kind": "Medical"},
        {"id": "c-4", "name": "Fire Service", "detail": "+234 806 000 1144", "kind": "Fire"},
        {"id": "c-3", "name": "Trusted contact: Mum", "detail": "+234 803 441 2290", "kind": "Family"}
    ]
}

DEMO_CREDENTIALS = {
    "student@mau.edu.ng": ("student123", "u-student"),
    "admin@mau.edu.ng": ("admin123", "u-admin"),
}
SESSIONS = {}
RESPONDER_ROLES = {"admin", "security", "clinic", "fire"}
SECURITY_CASE_TYPES = {"Security threat", "Accident", "Harassment", "Other"}
CLINIC_CASE_TYPES = {"Medical"}
FIRE_CASE_TYPES = {"Fire"}


def load_data():
    if not DATA_FILE.exists():
        DATA_FILE.write_text(json.dumps(DEFAULT_DATA, indent=2), encoding="utf-8")
    data = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    users_by_matric = {user.get("matric"): user for user in data.get("users", []) if user.get("matric")}
    for alert in data.get("alerts", []):
        student = users_by_matric.get(alert.get("matric"), {})
        if not alert.get("hostel"):
            alert["hostel"] = student.get("hostel", "Not provided")
        if not alert.get("room"):
            alert["room"] = student.get("room", "Not provided")
        if not alert.get("recipients"):
            alert["recipients"] = [
                {"name": "Campus Security Desk", "role": "security", "detail": "+234 806 000 1122", "status": "Notified"},
                {"name": "MAU Clinic", "role": "clinic", "detail": "+234 806 000 1133", "status": "Notified"},
                {"name": "Fire Service", "role": "fire", "detail": "+234 806 000 1144", "status": "Notified"},
                {"name": "Parent / trusted contact", "role": "parent", "detail": student.get("phone", "Not provided"), "status": "Notified"},
            ]
        elif not any(recipient.get("role") == "fire" for recipient in alert["recipients"]):
            alert["recipients"].insert(2, {"name": "Fire Service", "role": "fire", "detail": "+234 806 000 1144", "status": "Notified"})
    return data


def save_data(data):
    DATA_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def current_user(handler, data):
    token = handler.headers.get("X-Session-Token")
    user_id = SESSIONS.get(token)
    return next((user for user in data["users"] if user["id"] == user_id), None)


def build_recipients(data):
    recipient_map = {
        "Security": ("Campus Security Desk", "security"),
        "Medical": ("MAU Clinic", "clinic"),
        "Fire": ("Fire Service", "fire"),
        "Family": ("Parent / trusted contact", "parent"),
    }
    recipients = []
    for contact in data["contacts"]:
        if contact.get("kind") in recipient_map:
            recipients.append({
                "name": recipient_map[contact["kind"]][0],
                "role": recipient_map[contact["kind"]][1],
                "detail": contact.get("detail", ""),
                "status": "Notified",
            })
    return recipients


class AppHandler(BaseHTTPRequestHandler):
    def _send(self, payload, status=200, content_type="application/json"):
        if isinstance(payload, bytes):
            body = payload
        elif content_type == "application/json":
            body = json.dumps(payload).encode("utf-8")
        else:
            body = str(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        length = int(self.headers.get("Content-Length", 0))
        return json.loads(self.rfile.read(length) or b"{}")

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/overview":
            data = load_data()
            user = current_user(self, data)
            if not user:
                self._send({"error": "Authentication required"}, 401)
                return
            if user["role"] == "admin":
                alerts = data["alerts"]
            elif user["role"] == "security":
                alerts = [a for a in data["alerts"] if a.get("type") in SECURITY_CASE_TYPES]
            elif user["role"] == "clinic":
                alerts = [a for a in data["alerts"] if a.get("type") in CLINIC_CASE_TYPES]
            elif user["role"] == "fire":
                alerts = [a for a in data["alerts"] if a.get("type") in FIRE_CASE_TYPES]
            else:
                alerts = [a for a in data["alerts"] if a.get("matric") == user.get("matric")]
            contacts = data["contacts"] if user["role"] == "admin" else data["contacts"]
            self._send({"alerts": alerts, "allAlerts": data["alerts"], "contacts": contacts, "user": user})
            return
        if path == "/api/alerts":
            data = load_data()
            user = current_user(self, data)
            if not user or user["role"] != "admin":
                self._send({"error": "Admin access required"}, 403)
                return
            self._send({"alerts": data["alerts"]})
            return
        if path == "/" or path == "/index.html":
            self._serve_file("index.html", "text/html; charset=utf-8")
            return
        if path in ("/app.js", "/styles.css"):
            self._serve_file(path[1:], "text/javascript; charset=utf-8" if path.endswith(".js") else "text/css; charset=utf-8")
            return
        self._send({"error": "Not found"}, 404)

    def _serve_file(self, filename, content_type):
        file_path = ROOT / filename
        if not file_path.exists():
            self._send({"error": "Asset not found"}, 404)
            return
        self._send(file_path.read_bytes(), content_type=content_type)

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/api/login":
            payload = self._body()
            data = load_data()
            email = payload.get("email", "").lower()
            email_aliases = {"student@mau.edu.ng": "aisha.bello@mau.edu.ng", "admin@mau.edu.ng": "safety@mau.edu.ng"}
            email = email_aliases.get(email, email)
            user = next((candidate for candidate in data["users"] if candidate.get("email", "").lower() == email and candidate.get("password") == payload.get("password")), None)
            if not user:
                self._send({"error": "Invalid email or password"}, 401)
                return
            token = str(uuid.uuid4())
            SESSIONS[token] = user["id"]
            self._send({"token": token, "user": {key: value for key, value in user.items() if key != "password"}})
            return
        if path == "/api/register":
            payload = self._body()
            data = load_data()
            email = payload.get("email", "").strip().lower()
            if not email or not payload.get("password") or not payload.get("name") or not payload.get("matric") or not payload.get("hostel") or not payload.get("room"):
                self._send({"error": "Name, matric number, hostel name, room number, email, and password are required"}, 400)
                return
            if any(user.get("email", "").lower() == email for user in data["users"]):
                self._send({"error": "An account with this email already exists"}, 409)
                return
            user = {"id": "u-" + str(uuid.uuid4()), "name": payload["name"].strip(), "matric": payload["matric"].strip(), "phone": payload.get("phone", "").strip(), "hostel": payload["hostel"].strip(), "room": payload["room"].strip(), "role": "student", "email": email, "password": payload["password"]}
            data["users"].append(user)
            save_data(data)
            self._send({"message": "Registration successful. You can now sign in."}, 201)
            return
        if path == "/api/alerts":
            data = load_data()
            user = current_user(self, data)
            if not user or user["role"] != "student":
                self._send({"error": "Student access required"}, 403)
                return
            payload = self._body()
            alert = {
                "id": "AL-" + str(2409 + len(data["alerts"])),
                "type": payload.get("type", "Other"),
                "student": payload.get("student", "Aisha Bello"),
                "matric": payload.get("matric", "MAU/CSC/21/047"),
                "phone": payload.get("phone", "+234 803 441 2290"),
                "hostel": user.get("hostel", "Not provided"),
                "room": user.get("room", "Not provided"),
                "location": payload.get("location", "Location pending"),
                "lat": payload.get("lat"),
                "lng": payload.get("lng"),
                "status": "New",
                "time": datetime.now(timezone.utc).isoformat(),
                "channel": "Push + SMS",
                "recipients": build_recipients(data),
                "response_note": "Security Desk, Clinic, and parent notified."
            }
            data["alerts"].insert(0, alert)
            save_data(data)
            self._send({"alert": alert}, 201)
            return
        if path.startswith("/api/alerts/") and path.endswith("/status"):
            alert_id = path.split("/")[3]
            payload = self._body()
            data = load_data()
            user = current_user(self, data)
            if not user or user["role"] not in RESPONDER_ROLES:
                self._send({"error": "Admin access required"}, 403)
                return
            for alert in data["alerts"]:
                if alert["id"] == alert_id:
                    recipient_role = payload.get("recipient")
                    allowed_type = user["role"] == "admin" or (user["role"] == "security" and alert.get("type") in SECURITY_CASE_TYPES) or (user["role"] == "clinic" and alert.get("type") in CLINIC_CASE_TYPES) or (user["role"] == "fire" and alert.get("type") in FIRE_CASE_TYPES)
                    if not allowed_type:
                        self._send({"error": "This responder cannot handle this incident type"}, 403)
                        return
                    if user["role"] in ("security", "clinic", "fire") and recipient_role != user["role"]:
                        self._send({"error": "You can only update your responder case"}, 403)
                        return
                    if recipient_role and alert.get("recipients"):
                        for recipient in alert["recipients"]:
                            if recipient.get("role") == recipient_role:
                                recipient["status"] = payload.get("status", recipient["status"])
                        recipient_statuses = [recipient.get("status") for recipient in alert["recipients"] if recipient.get("role") in ("security", "clinic", "fire")]
                        alert["status"] = "Resolved" if recipient_statuses and all(status == "Resolved" for status in recipient_statuses) else "Responding" if any(status in ("Responding", "Resolved") for status in recipient_statuses) else "New"
                    else:
                        alert["status"] = payload.get("status", alert["status"])
                    if alert["status"] == "Responding":
                        alert["response_note"] = "Security Desk and Clinic are responding."
                    elif alert["status"] == "Resolved":
                        alert["response_note"] = "Security Desk and Clinic resolved the incident."
                    save_data(data)
                    self._send({"alert": alert})
                    return
            self._send({"error": "Alert not found"}, 404)
            return
        if path == "/api/contacts":
            data = load_data()
            if not current_user(self, data):
                self._send({"error": "Authentication required"}, 401)
                return
            payload = self._body()
            contact = {"id": str(uuid.uuid4()), "name": payload.get("name", "Trusted contact"), "detail": payload.get("detail", ""), "kind": payload.get("kind", "Family")}
            data["contacts"].append(contact)
            save_data(data)
            self._send({"contact": contact}, 201)
            return
        self._send({"error": "Not found"}, 404)

    def log_message(self, format, *args):
        return


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    print(f"MAU PEACE Alert running on port {port}. Use this computer's Wi-Fi IP from your phone.")
    ThreadingHTTPServer(("0.0.0.0", port), AppHandler).serve_forever()
