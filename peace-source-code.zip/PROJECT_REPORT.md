# PEACE Student Emergency Alert App

## Project Report

### Abstract

PEACE is a browser-based student emergency alert system for Modibbo Adama University. It allows registered students to report medical, security, fire, accident, harassment, and other emergencies. The system captures student identity, hostel and room information, GPS coordinates when permission is granted, and sends a dispatch record to the appropriate response teams, a parent or trusted contact, and the campus safety desk.

The system includes separate secure workspaces for students, Campus Safety Desk administrators, Security Office, MAU Clinic, and Fire Service. Each specialist responder receives only the incident categories assigned to that service and can update only its own response status.

### Chapter One: Introduction

#### 1.1 Background

Students may experience medical emergencies, fire, assault, accidents, theft, harassment, or other threats while on or near campus. Traditional reporting by phone call, physical visits, or manual text messages can delay help and may be difficult during panic. PEACE provides a structured digital reporting channel designed for rapid use on a smartphone or computer.

#### 1.2 Problem Statement

The previous manual process has four major weaknesses: delayed reporting, incomplete student location details, poor coordination between response teams, and limited incident records. The proposed system addresses these weaknesses with a one-tap alert flow, GPS support, structured dispatch records, role-based access, and response tracking.

#### 1.3 Aim and Objectives

The aim is to provide a reliable student-centered emergency reporting and response platform. Objectives are to:

1. Register students with identity, phone, hostel, and room details.
2. Provide secure login for students and response services.
3. Capture the emergency type and device location.
4. Route cases to Security Office, MAU Clinic, Fire Service, Campus Safety Desk, and parent or trusted contact.
5. Restrict each responder to its assigned incident category.
6. Record acknowledgement and resolution actions.
7. Show the student the progress of every notified responder.

#### 1.4 Scope

The prototype covers registration, login, student alerts, GPS map display, incident history, trusted contacts, responder dashboards, role permissions, and JSON persistence. Production SMS, push notification, email, and WhatsApp delivery are represented by dispatch records and should be connected to external providers before institutional use.

### Chapter Two: Literature and Conceptual Review

Emergency alert platforms reduce communication friction by replacing a long explanation with structured incident data. Location services make a report more actionable because dispatchers can identify the student's approximate position. Role-based access is important because medical staff should not manage security cases, and fire responders should focus on fire incidents.

The design follows the Technology Acceptance Model principles of perceived usefulness and perceived ease of use. The panic workflow is short, the main action is visually prominent, and the interface displays service status in simple terms. The system also follows the emergency management cycle: report, notify, respond, resolve, and record.

### Chapter Three: Methodology and System Design

#### 3.1 Development Method

The prototype uses an iterative development approach. Requirements were translated into interface and API changes, tested through browser interaction, and refined after each runtime check.

#### 3.2 Architecture

The browser client is served by a Python HTTP server. The client communicates with JSON endpoints using authenticated session tokens. Data is persisted in `data.json`. Leaflet and OpenStreetMap provide the interactive map layer.

Student device -> authenticated API -> dispatch record -> specialist response workspace -> student status view

#### 3.3 Roles and Permissions

- Student: must register and sign in; can create and view personal cases.
- Campus Safety Desk: can view all cases and coordinate the whole queue.
- Security Office: can view and resolve Security threat, Accident, Harassment, and Other cases.
- MAU Clinic: can view and resolve Medical cases only.
- Fire Service: can view and resolve Fire cases only.

#### 3.4 Alert Data

Each new alert can contain student name, matric number, phone, hostel, room, selected emergency type, reported location, latitude, longitude, time, recipient list, recipient statuses, and response note.

#### 3.5 Location Design

The map requests high-accuracy browser geolocation. When permission is granted, the interface watches the device location, displays a live marker, shows estimated accuracy, recenters the map, and attaches the latest coordinates to a new alert. If permission is denied or unavailable, the alert remains usable and records that GPS was unavailable.

### Chapter Four: Implementation and Screenshots

#### 4.1 Login and Registration

The login screen supports secure access for students and response services. Student registration is separate and requires hostel name and room number before the account can be created.

![Login](report-screenshots/01-login.png)

![Student registration](report-screenshots/02-registration.png)

#### 4.2 Student Workspace

The student dashboard provides the emergency action, personal alert history, trusted contacts, profile settings, responder statuses, and the interactive location map.

![Student dashboard](report-screenshots/03-student-dashboard.png)

#### 4.3 Administrative Workspace

The Campus Safety Desk can see the complete incident queue, inspect student identity and location details, view recipient progress, and coordinate resolution.

![Admin dashboard](report-screenshots/04-admin-dashboard.png)

#### 4.4 Specialist Workspaces

The specialist workspaces demonstrate category-based routing. Security sees security cases, Clinic sees medical cases, and Fire Service sees fire cases.

![Security dashboard](report-screenshots/05-security-dashboard.png)

![Clinic dashboard](report-screenshots/06-clinic-dashboard.png)

![Fire Service dashboard](report-screenshots/07-fire-service-dashboard.png)

### Chapter Five: Testing, Results, and Conclusion

#### 5.1 Tests Performed

- Verified server syntax and JSON validity.
- Verified student registration rejects missing hostel or room.
- Verified student, admin, Security, Clinic, and Fire Service login roles.
- Verified Security receives only assigned security-related cases.
- Verified Clinic receives only Medical cases.
- Verified Fire Service receives only Fire cases.
- Verified specialist users cannot update another service's case.
- Verified student case records include responder statuses.
- Verified the map loads Leaflet and OpenStreetMap tiles.
- Verified browser GPS permission path and live location marker path.

#### 5.2 Results

The local prototype successfully supports a complete workflow from student registration through incident reporting and service-specific resolution. The response model prevents unrelated specialist action and makes case progress visible to the reporting student.

#### 5.3 Limitations

The prototype uses JSON storage and demo passwords. Browser GPS requires HTTPS or localhost and explicit permission. Notification delivery is represented locally and is not yet connected to a real SMS, push, email, or WhatsApp provider. Public hosting requires a deployment account and production security configuration.

#### 5.4 Conclusion

PEACE provides a practical foundation for a student emergency communication system. Its registration data, live location support, service-specific routing, and response tracking address the main weaknesses of manual emergency reporting. Production deployment should add a database, password hashing, HTTPS, audit logging, verified institutional accounts, and real notification providers.

## Public Access Deployment

The server already binds to `0.0.0.0` and reads the platform `PORT` variable. To access the app from anywhere, deploy the folder to a service such as Render, Railway, or an institutional server. Use this start command:

```text
python server.py
```

After deployment, open the public HTTPS URL supplied by the host. HTTPS is required for real browser GPS access outside localhost. Do not use the demo passwords in production.
