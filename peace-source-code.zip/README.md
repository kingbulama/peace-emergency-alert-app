# PEACE Student Emergency Alert

A dependency-free full-stack prototype based on the PEACE project brief for Modibbo Adama University. It includes a Python REST backend and a responsive browser dashboard for students.

## Run

From this folder:

```powershell
python server.py
```

Open http://localhost:8000.

## Use on a phone over Wi-Fi

Connect the phone and this computer to the same Wi-Fi network. Find the computer's IPv4 address with `ipconfig`, then open this address on the phone:

```text
http://10.84.130.106:8000
```

The address may change when the computer reconnects to Wi-Fi. If Windows Firewall blocks the connection, run PowerShell as Administrator once:

```powershell
New-NetFirewallRule -DisplayName "PEACE Emergency Alert App" -Direction Inbound -Protocol TCP -LocalPort 8000 -Action Allow
```

For access from outside the local Wi-Fi network, deploy the app to a public HTTPS host using `render.yaml`. HTTPS is required for browser GPS on a public domain.

## Demo accounts

- Student: `student@mau.edu.ng` / `student123`
- Admin: `admin@mau.edu.ng` / `admin123`
- Security Office: `security@mau.edu.ng` / `security123`
- MAU Clinic: `clinic@mau.edu.ng` / `clinic123`
- Fire Service: `fire@mau.edu.ng` / `fire123`

## Included

- One-tap emergency alert flow with emergency type selection
- Browser GPS capture when permission is available
- Persistent JSON incident records and trusted contacts
- Student dashboard, alert history, contacts, and profile views
- Role-aware student and admin workspaces with session-protected API routes
- Real Leaflet map using OpenStreetMap tiles and stored incident coordinates
- Emergency dispatch record for Campus Security Desk, MAU Clinic, and parent/trusted contact
- Admin acknowledge and resolve actions with response status notes
- Student registration is required before student access
- Separate Security Office and MAU Clinic responder accounts
- Separate Fire Service responder account and fire-only case queue
- Alert payload includes name, matric number, phone, GPS coordinates, time, type, and Push + SMS channel status

The local prototype records each notification recipient and response action. Production deployment should connect the dispatch record to Firebase Cloud Messaging, an SMS provider, email/WhatsApp delivery as required, replace demo credentials with hashed accounts and a persistent session store, and use a real database. For public access, deploy with the included `render.yaml` or use any Python host with start command `python server.py`; use the public HTTPS URL for GPS access outside localhost.

See [PROJECT_REPORT.md](PROJECT_REPORT.md) for the detailed chapter report and [report-screenshots](report-screenshots) for generated screen captures.
